﻿using Livraria_BCC.Models;
using Livraria_BCC.Repositorio;
using System.Collections.Generic;
using System.Linq;

namespace Livraria_BCC.Aplicacao
{
    public class AutorAplicacao
    {
        private readonly Contexto contexto;

        public AutorAplicacao()
        {
            contexto = new Contexto();
        }

        #region Listar Por Id

        public Autor ListarPorId(int id)
        {
            var autores = new List<Autor>();
            const string strQuery = "SELECT AutorId, Nome, Email FROM Autor WHERE AutorId = @AutorId";
            var parametros = new Dictionary<string, object>
            {
                {"AutorId", id}
            };
            var rows = contexto.ExecutaComandoComRetorno(strQuery, parametros);
            foreach (var row in rows)
            {
                var tempAutor = new Autor
                {
                    AutorId = int.Parse(!string.IsNullOrEmpty(row["AutorId"]) ? row["AutorId"] : "0"),
                    Nome = row["Nome"],
                    Email = row["Email"]
                };
                autores.Add(tempAutor);
            }

            return autores.FirstOrDefault();
        }

        #endregion

        #region Listar Todos

        public List<Autor> ListarTodos()
        {
            List<Autor> autores = new List<Autor>();
            var strQuery = "SELECT AutorId, Nome, Email FROM Autor";

            var rows = contexto.ExecutaComandoComRetorno(strQuery);
            foreach (var row in rows)
            {
                var tempAutor = new Autor
                {
                    AutorId = int.Parse(!string.IsNullOrEmpty(row["AutorId"]) ? row["AutorId"] : "0"),
                    Nome = row["Nome"],
                    Email = row["Email"]
                };
                autores.Add(tempAutor);
            }

            return autores;
        }

        #endregion

        #region Inserir

        public int Inserir(Autor autor)
        {
            var commandText = "INSERT INTO Autor (AutorId, Nome, Email) VALUES (@AutorId, @Nome, @Email)";

            var parameters = new Dictionary<string, object>
            {
                {"AutorId", autor.AutorId},
                { "Nome",autor.Nome },
                {"Email", autor.Email}
            };

            return contexto.ExecutaComando(commandText, parameters);
        }

        #endregion

        #region Alterar

        public int Alterar(Autor autor)
        {
            var commandText = " UPDATE Autor SET ";
            commandText += " Nome = @Nome, ";
            commandText += " Email = @Email ";
            commandText += " WHERE AutorId = @AutorId ";

            var parameters = new Dictionary<string, object>
            {
                {"AutorId", autor.AutorId},
                {"Nome", autor.Nome},
                {"Email", autor.Email},
            };

            return contexto.ExecutaComando(commandText, parameters);
        }

        #endregion

        #region Excluir

        public int Excluir(int id)
        {
            const string strQuery = "DELETE FROM Autor WHERE AutorId = @Id";

            var parametros = new Dictionary<string, object>
            {
                {"Id", id}
            };

            return contexto.ExecutaComando(strQuery, parametros);
        }

        #endregion

        #region Outros Métodos

        public bool VerificaSeAutorTemLivroCadastrado (int id)
        {
            var strQuery = "SELECT Livro.LivroId FROM Livro ";
            strQuery += "INNER JOIN Autor ON Livro.AutorId = Autor.AutorId ";
            strQuery += "AND Autor.AutorId = @Id";

            var parametros = new Dictionary<string, object>
            {
                {"Id", id}
            };

            var rows = contexto.ExecutaComandoComRetorno(strQuery, parametros);
            return (rows.Count > 0) ? true : false;
        }

        #endregion
    }
}