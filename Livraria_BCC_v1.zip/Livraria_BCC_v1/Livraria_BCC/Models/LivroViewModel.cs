﻿using System.ComponentModel.DataAnnotations;
using System.Web;

namespace Livraria_BCC.Models
{
    public class LivroViewModel
    {
        [Key]
        public int LivroId { get; set; }

        [Required(ErrorMessage = "O ISBN do livro é obrigatório", AllowEmptyStrings = false)]
        [Display(Name = "ISBN do Livro")]
        public string ISBN { get; set; }

        [Required(ErrorMessage = "O nome do lvro é obrigatório", AllowEmptyStrings = false)]
        [Display(Name = "Nome do Livro")]
        public string Nome { get; set; }
                       
        [Required(ErrorMessage = "Informe o preço do livro", AllowEmptyStrings = false)]
        [DisplayFormat(DataFormatString = "{0:C2}", ApplyFormatInEditMode = true)]
        [Display(Name = "Preço")]
        public decimal Preco { get; set; }

        [Required(ErrorMessage = "A data de publicação do livro é obrigatória", AllowEmptyStrings = false)]
        [DisplayFormat(DataFormatString = "{0:mm/dd/yyyy}", ApplyFormatInEditMode = true)]
        [DataType(DataType.Date, ErrorMessage = "Data em formato inválido")]
        [Display(Name = "Data de Publicação")]
        public string DataPublicacao { get; set; }

        [Required(ErrorMessage = "Selecione um autor", AllowEmptyStrings = false)]
        [Display(Name = "Autores")]
        public int AutorId { get; set; }

        [Required(ErrorMessage = "Selecione uma imagem da capa do livro", AllowEmptyStrings = false)]
        [DataType(DataType.Upload)]
        [Display(Name = "Imagem da Capa")]
        public HttpPostedFileBase ImagemCapa { get; set; }

        [Display(Name = "Nome do Autor")]
        public string AutorNome { get; set; }
    }
}