﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Livraria_BCC.Models
{
    public class Autor
    {
        [Key]
        public int AutorId { get; set; }

        [Required(ErrorMessage = "Favor preencha o campo Nome.", AllowEmptyStrings = false)]
        [Display(Name = "Nome")]
        public string Nome { get; set; }

        [Required(ErrorMessage = "Favor preencha o campo de E-mail.", AllowEmptyStrings = false)]
        [Display(Name = "E-mail")]
        public string Email { get; set; }

        public List<Autor> ListaAutores { get; set; }

        public List<Livro> Livros { get; set; }        
    }   
}