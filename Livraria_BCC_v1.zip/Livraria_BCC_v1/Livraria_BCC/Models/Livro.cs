﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Livraria_BCC.Models
{
    public class Livro
    {
        [Key]
        public int LivroId { get; set; }

        [Required(ErrorMessage = "Favor informar o ISBN do livro.", AllowEmptyStrings = false)]
        [Display(Name = "ISBN do Livro")]
        public string ISBN { get; set; }

        [Required(ErrorMessage = "Favor informar o nome do livro.", AllowEmptyStrings = false)]
        [Display(Name = "Nome do Livro")]
        public string Nome { get; set; }

        [Required(ErrorMessage = "Favor informar preço do livro.", AllowEmptyStrings = false)]
        [DisplayFormat(DataFormatString = "{0,2}", ApplyFormatInEditMode = true)]
        [Display(Name = "Preço")]
        public decimal Preco { get; set; }

        [Required(ErrorMessage = "Favor informar a data de publicação do livro.", AllowEmptyStrings = false)]
        [DisplayFormat(DataFormatString = "{0:mm/dd/yyyy}", ApplyFormatInEditMode = true)]
        [DataType(DataType.Date, ErrorMessage = "Data em formato inválido")]
        [Display(Name = "Data de Publicação")]
        public String DataPublicacao { get; set; }

        [Required(ErrorMessage = "Selecione um autor", AllowEmptyStrings = false)]
        [ForeignKey("AutorId")]
        [Display(Name = "Autores")]
        public int AutorId { get; set; }

        [Display(Name = "Imagem da Capa")]
        public byte[] ImagemCapa { get; set; }
        
        public virtual Autor Autor { get; set; }

        [Display(Name = "Nome do Autor")]
        public string AutorNome { get; set; }
    }
}