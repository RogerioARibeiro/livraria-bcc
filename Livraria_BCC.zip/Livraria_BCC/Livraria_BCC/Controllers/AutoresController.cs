﻿using Livraria_BCC.Aplicacao;
using System;
using System.Linq;
using System.Web.Mvc;

namespace Livraria_BCC.Models
{
    public class AutoresController : Controller
    {
        private AutorAplicacao autorAplicacao = new AutorAplicacao();

        [HttpGet]
        public ActionResult ListarAutores()
        {
            var autores = autorAplicacao.ListarTodos().OrderBy(c => c.Nome);
            return View(autores);
        }

        #region Detalhar Autor

        [HttpGet]
        public ActionResult DetalharAutor(int id)
        {
            var autor = autorAplicacao.ListarPorId(id);
            return View(autor);
        }

        #endregion

        #region Incluir Autor

        [HttpGet]
        public ActionResult IncluirAutor()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult IncluirAutor(Autor autor)
        {
            if (ModelState.IsValid)
            {
                autor.AutorId = autorAplicacao.ListarTodos().Select(m => m.AutorId).Max() + 1;
                autorAplicacao.Inserir(autor);
            }

            return RedirectToAction("ListarAutores");
        }

        #endregion

        #region Editar Autor

        [HttpGet]
        public ActionResult EditarAutor(int id)
        {
            var autor = autorAplicacao.ListarPorId(id);
            return View(autor);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditarAutor(Autor autor)
        {
            if (ModelState.IsValid)
                autorAplicacao.Alterar(autor);

            return RedirectToAction("ListarAutores");
        }

        #endregion             

        #region Excluir Autor

        [HttpGet]
        public ActionResult ExcluirAutor(long id)
        {
            var autor = autorAplicacao.ListarPorId(Convert.ToInt32(id));
            return View(autor);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ExcluirAutor(int id)
        {
            if (autorAplicacao.VerificaSeAutorTemLivroCadastrado(id))
                ModelState.AddModelError("Nome", "O Autor não pode ser excluído, pois o mesmo tem pelo menos um livro cadastrado.");

            if (ModelState.IsValid)
                autorAplicacao.Excluir(id);            

            return RedirectToAction("ListarAutores");
        }

        #endregion
    }
}