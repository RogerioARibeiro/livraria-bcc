﻿using Livraria_BCC.Aplicacao;
using Livraria_BCC.Models;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Web.Mvc;

namespace Livraria_BCC.Controllers
{
    public class LivrosController : Controller
    {
        private LivroAplicacao livroAplicacao = new LivroAplicacao();
        private AutorAplicacao autorAplicacao = new AutorAplicacao();

        [HttpGet]
        public ActionResult ListarLivros()
        {
            var livros = livroAplicacao.ListarTodos().OrderBy(c => c.Nome);
            if (livros == null)            
                return HttpNotFound();
            
            return View(livros);
        }

        #region Detalhar Livros

        [HttpGet]
        public ActionResult DetalharLivro(int id)
        {
            if (id.ToString() == null)            
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
           
            var livro = livroAplicacao.ListarPorId(id);
            if (livro == null)            
                return HttpNotFound();
            
            return View(livro);
        }

        #endregion

        #region Incluir Livros

        [HttpGet]
        public ActionResult IncluirLivro()
        {
            carregaViewBagDropBoxList();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult IncluirLivro(LivroViewModel model)
        {
            var imageTypes = new string[]{
                "image/gif",
                "image/jpeg",
                "image/pjpeg",
                "image/png"
            };

            if (model.ImagemCapa == null || model.ImagemCapa.ContentLength == 0)            
                ModelState.AddModelError("ImagemCapa", "Este campo é obrigatório");            
            else if (!imageTypes.Contains(model.ImagemCapa.ContentType))            
                ModelState.AddModelError("ImagemCapa", "Escolha uma iamgem GIF, JPG ou PNG.");

            if (livroAplicacao.VerificaSeISBNCadastrado(model.ISBN))
                ModelState.AddModelError("ISBN", "Já existe um livro cadastrado com O ISBN informado.");

            if (ModelState.IsValid)
            {
                var livro = new Livro();
                livro.LivroId = livroAplicacao.ListarTodos().Select(m => m.LivroId).Max() + 1;
                livro.ISBN = model.ISBN;
                livro.Nome = model.Nome;
                livro.Preco = model.Preco;
                livro.DataPublicacao = Convert.ToDateTime(model.DataPublicacao).ToString("yyyy-MM-dd");
                livro.AutorId = model.AutorId;                

                //lê a imagem e a seguir os bytes armazenados
                using (var binaryReader = new BinaryReader(model.ImagemCapa.InputStream))
                    livro.ImagemCapa = binaryReader.ReadBytes(model.ImagemCapa.ContentLength);
                                
                livroAplicacao.Inserir(livro);
                return RedirectToAction("ListarLivros");
            }

            // Se ocorrer um erro retorna para página
            carregaViewBagDropBoxList();
            return View(model);
        }

        #endregion

        #region Editar Livro

        [HttpGet]
        public ActionResult EditarLivro(int id)
        {
            if (id.ToString() == null)            
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            
            var livro = livroAplicacao.ListarTodos().Where(m => m.LivroId == id).First();
            if (livro == null)            
                return HttpNotFound();            

            carregaViewBagDropBoxList();
            return View(livro);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditarLivro(Livro livro)
        {
            if (ModelState.IsValid)
            {
                if (livro == null)                
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);                

                livroAplicacao.Alterar(livro);
                return RedirectToAction("ListarLivros");
            }

            // Se ocorrer um erro retorna para página
            carregaViewBagDropBoxList();
            return View(livro);
        }

        #endregion

        #region Excluir Livro

        [HttpGet]
        public ActionResult ExcluirLivro(long id)
        {
            var livro = livroAplicacao.ListarPorId(Convert.ToInt32(id));
            return View(livro);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ExcluirLivro(int id)
        {
            livroAplicacao.Excluir(id);
            return RedirectToAction("ListarLivros");
        }

        #endregion

        #region Outros Métodos

        private void carregaViewBagDropBoxList()
        {
            ViewBag.Autores = autorAplicacao.ListarTodos();
        }

        #endregion
    }
}