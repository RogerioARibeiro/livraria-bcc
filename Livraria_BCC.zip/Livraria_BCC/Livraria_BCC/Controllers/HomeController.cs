﻿using System.Web.Mvc;

namespace Livraria_BCC.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
    }
}
