﻿using System.Data.Entity;

namespace Livraria_BCC.Models
{
    public class LivroDbContext : DbContext
    {
        public DbSet<Livro> Livros { get; set; }
        public DbSet<Autor> Autores { get; set; }
    }
}