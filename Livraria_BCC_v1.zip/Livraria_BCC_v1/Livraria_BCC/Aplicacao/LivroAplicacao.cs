﻿using Livraria_BCC.Models;
using Livraria_BCC.Repositorio;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Livraria_BCC.Aplicacao
{
    public class LivroAplicacao
    {
        private readonly Contexto contexto;

        public LivroAplicacao()
        {
            contexto = new Contexto();
        }

        #region Listar Por Id

        public Livro ListarPorId(int id)
        {
            var livros = new List<Livro>();

            var strQuery = "SELECT Livro.LivroId, Livro.Nome, Livro.ISBN, Livro.DataPublicacao, ";
            strQuery += "Livro.Preco, Livro.ImagemCapa, Autor.Nome AS AutorNome ";
            strQuery += "FROM Livro INNER JOIN Autor ON Livro.AutorId = Autor.AutorId ";
            strQuery += "WHERE LivroId = @LivroId";

            var parametros = new Dictionary<string, object>
            {
                {"LivroId", id}
            };
            var rows = contexto.ExecutaComandoComRetorno(strQuery, parametros);
            foreach (var row in rows)
            {
                var tempLivro = new Livro
                {
                    //TODO: Descobrir o erro e liberar o código
                    LivroId = int.Parse(!string.IsNullOrEmpty(row["LivroId"]) ? row["LivroId"] : "0"),
                    Nome = row["Nome"],
                    ISBN = row["ISBN"],
                    DataPublicacao = Convert.ToDateTime(row["DataPublicacao"]).ToString("dd-MM-yyyy"),
                    Preco = Math.Round(Convert.ToDecimal(row["Preco"]), 2),
                    //ImagemCapa = Convert.FromBase64String(row["ImagemCapa"]),
                    AutorNome = row["AutorNome"]
                };
                livros.Add(tempLivro);
            }

            return livros.FirstOrDefault();
        }

        #endregion

        #region Listar Todos

        public List<Livro> ListarTodos()
        {
            List<Livro> livros = new List<Livro>();

            var strQuery = "SELECT Livro.LivroId, Livro.Nome, Livro.ISBN, Livro.DataPublicacao, ";
            strQuery += "Livro.Preco, Livro.ImagemCapa, Autor.Nome AS AutorNome ";
            strQuery += "FROM Livro INNER JOIN Autor ON Livro.AutorId = Autor.AutorId";
            
            var rows = contexto.ExecutaComandoComRetorno(strQuery);
            foreach (var row in rows)
            {
                var tempLivro = new Livro
                {
                    //TODO: Descobrir o tipo correto e retirar o NULL da linha
                    LivroId = int.Parse(!string.IsNullOrEmpty(row["LivroId"]) ? row["LivroId"] : "0"),
                    Nome = row["Nome"],
                    ISBN = row["ISBN"],
                    DataPublicacao = Convert.ToDateTime(row["DataPublicacao"]).ToString("dd-MM-yyyy"),
                    Preco = Math.Round(Convert.ToDecimal(row["Preco"]), 2),
                    ImagemCapa = null, //ConvertFromBase64String(row["ImagemCapa"]),
                    AutorNome = row["AutorNome"]
                };
                livros.Add(tempLivro);
            }

            return livros;
        }

        #endregion

        #region Inserir

        public int Inserir(Livro livro)
        {
            var commandText = "INSERT INTO Livro (LivroId, AutorId, Nome, ISBN, DataPublicacao, Preco, ImagemCapa) ";
            commandText += "VALUES (@LivroId,@AutorId, @Nome, @ISBN, @DataPublicacao, @Preco, @ImagemCapa)";

            var parameters = new Dictionary<string, object>
            {
                {"LivroId", livro.LivroId},
                {"AutorId", livro.AutorId},
                {"Nome", livro.Nome},
                {"ISBN", livro.ISBN},
                {"DataPublicacao", Convert.ToDateTime(livro.DataPublicacao)},
                {"Preco", livro.Preco},
                {"ImagemCapa", livro.ImagemCapa}
            };

            return contexto.ExecutaComando(commandText, parameters);
        }

        #endregion

        #region Alterar

        public int Alterar(Livro livro)
        {
            //TODO: Descobrir o erro e liberar o código
            var commandText = " UPDATE Livro SET ";
            commandText += " AutorId = @AutorId, ";            
            commandText += " ISBN = @ISBN, ";
            commandText += " Nome = @Nome, ";
            commandText += " DataPublicacao = @DataPublicacao, ";
            commandText += " Preco = @Preco ";
            //commandText += " ImagemCapa = @ImagemCapa ";
            commandText += " WHERE LivroId = @LivroId ";

            var parameters = new Dictionary<string, object>
            {
                {"LivroId", livro.LivroId},
                {"AutorId", livro.AutorId},
                {"ISBN", livro.ISBN},
                {"Nome", livro.Nome},
                {"DataPublicacao", Convert.ToDateTime(livro.DataPublicacao)},
                {"Preco", livro.Preco}//,
                //{"ImagemCapa", livro.ImagemCapa}
            };

            return contexto.ExecutaComando(commandText, parameters);
        }

        #endregion

        #region Excluir

        public int Excluir(int id)
        {
            const string strQuery = "DELETE FROM Livro WHERE LivroId = @Id";
            var parametros = new Dictionary<string, object>
            {
                {"Id", id}
            };

            return contexto.ExecutaComando(strQuery, parametros);
        }

        #endregion

        #region Outros Métodos

        public bool VerificaSeISBNCadastrado(string isbn)
        {
            if (String.IsNullOrEmpty(isbn))
                return false;
            else
            {
                var strQuery = "SELECT ISBN FROM Livro ";
                strQuery += "WHERE TRIM(ISBN) = @ISBN";

                var parametros = new Dictionary<string, object>
                {
                    {"ISBN", isbn.Trim()}
                };

                var rows = contexto.ExecutaComandoComRetorno(strQuery, parametros);
                return (rows.Count > 0) ? true : false;
            }
        }

        #endregion
    }
}